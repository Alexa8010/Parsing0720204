import scrapy
from ..items import UnspleshImgItem

# class UnsplashImgSpider(scrapy.Spider):
#     name = "unsplash_img"
#     # allowed_domains = ["unsplash.com"]
#     start_urls = ["https://unsplash.com"]

#     def parse(self, response):
#         for image_page in response.xpath('//*[@id=":rg2:"]/div/div/div/figure/a/@href').extract():
#             yield scrapy.Request(response.urljoin(image_page), self.parse_image_page)
            
#     def parse_image_page(self, response):
#         full_image_page_url = response.xpath('//*[contains(@class, "fullImageLink")]/a/@href').extract_first()
#         if full_image_page_url:
#             yield scrapy.Request(response.urljoin(full_image_page_url), self.save_image)
            
#     def save_image(self, response):
#         filename = response.url.split('/')[-1]
#         with open(f'images/{filename}', 'wb') as f:
#             f.write(response.body)

#############################################################################################################
# class UnsplashImgSpider(scrapy.Spider):
#     name = 'unsplash_img'
#     start_urls = ['https://unsplash.com/']

#     def parse(self, response):
#         # Извлечение ссылок на категории
#         category_links = response.xpath('//a[contains(@href, "/t/")]/@href | //li[contains(@class, "ul3z")]/a/@href').getall()
#         for link in category_links:
#             yield response.follow(link, self.parse_category)

#     def parse_category(self, response):
#         # Извлечение ссылок на фотографии в категории
#         photo_links = response.xpath('//a[contains(@class, "Prxeh")]/@href').getall()
#         for link in photo_links:
#             yield response.follow(link, self.parse_img)

#     def parse_img(self, response):
#         item = UnspleshImgItem()
        
#         # Извлечение URL изображения
#         item['image_url'] = response.xpath('//img[contains(@class, "YVj9w")]/@src').get(default='')
        
#         # Извлечение заголовка фотографии
#         item['title'] = response.xpath('//h1/text()').get(default='').strip()
        
#         # Извлечение категории (если доступно)
#         item['category'] = response.xpath('//a[contains(@href, "/t/")]/text()').get(default='')
        
       ######################################################################################################
       
class UnsplashImgSpider(scrapy.Spider):
    name = 'unsplash_img'
    start_urls = ['https://unsplash.com/']
    
    image_count = 0
    max_images = 50 

    def parse(self, response):
        # Извлечение ссылок на категории
        category_links = response.xpath('//a[contains(@href, "/t/")]/@href | //li[contains(@class, "ul3z")]/a/@href').getall()
        for link in category_links:
            yield response.follow(link, self.parse_category)

    def parse_category(self, response):
        # Извлечение ссылок на фотографии в категории
        photo_links = response.xpath('//a[contains(@class, "Prxeh")]/@href').getall()
        for link in photo_links:
            yield response.follow(link, self.parse_img)

    def parse_img(self, response):
        if self.image_count >= self.max_images:
            self.log("Достигнуто максимальное количество изображений. Остановка паука.")
            return  # Остановка паука
        item = UnspleshImgItem()
        
        # Извлечение URL изображения
        item['image_url'] = response.xpath('//img[contains(@class, "O9fwi")]/@src').get(default='')
        
        # Извлечение заголовка фотографии
        item['title'] = response.xpath('//h1/text()').get(default='').strip()
        
        # Извлечение категории (если доступно)
        item['category'] = response.xpath('//a[@class = "lKaxc SfGU7"]/text()').get(default='') 
        
        self.image_count += 1
        
        print(f"Image URL: {item['image_url']}, Title: {item['title']}, Category: {item['category']}")
        
        yield item